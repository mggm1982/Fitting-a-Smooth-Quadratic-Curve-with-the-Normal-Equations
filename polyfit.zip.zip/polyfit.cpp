#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <iomanip>
#include <algorithm>
using namespace std;

using Mat = vector<vector<double>>;

void printMat(const string& name, const Mat& M) {
    cout << name << " =\n";
    for (auto& row : M) {
        cout << "  [";
        for (double v : row) cout << setw(11) << fixed << setprecision(4) << v;
        cout << " ]\n";
    }
}

// Solve 3x3 system M c = b by Gaussian elimination with partial pivoting
bool solve3x3(Mat M, vector<double> b, vector<double>& c) {
    const int n = 3;
    for (int i = 0; i < n; ++i) {
        int piv = i;                                   // pick the largest pivot
        for (int r = i + 1; r < n; ++r)
            if (fabs(M[r][i]) > fabs(M[piv][i])) piv = r;
        if (fabs(M[piv][i]) < 1e-12) return false;     // singular
        swap(M[i], M[piv]); swap(b[i], b[piv]);
        for (int r = i + 1; r < n; ++r) {              // eliminate below
            double f = M[r][i] / M[i][i];
            for (int k = i; k < n; ++k) M[r][k] -= f * M[i][k];
            b[r] -= f * b[i];
        }
    }
    c.assign(n, 0.0);
    for (int i = n - 1; i >= 0; --i) {                 // back substitution
        double s = b[i];
        for (int k = i + 1; k < n; ++k) s -= M[i][k] * c[k];
        c[i] = s / M[i][i];
    }
    return true;
}

void writeSVG(const string& file, const vector<double>& x, const vector<double>& y,
              const vector<double>& c) {
    //Plot, range and margins            
    const double W = 700, H = 460, L = 70, R = 30, T = 50, B = 60;
    double xmin = *min_element(x.begin(), x.end()), xmax = *max_element(x.begin(), x.end());
    double pad = 0.1 * (xmax - xmin); xmin -= pad; xmax += pad;

    auto f = [&](double t) { return c[0] + c[1] * t + c[2] * t * t; };
    double ymin = *min_element(y.begin(), y.end()), ymax = *max_element(y.begin(), y.end());
    for (int i = 0; i <= 200; ++i) {
        double v = f(xmin + (xmax - xmin) * i / 200.0);
        ymin = min(ymin, v); ymax = max(ymax, v);
    }
    double yp = 0.1 * (ymax - ymin); ymin -= yp; ymax += yp;
    
    //Data to pixels
    auto sx = [&](double v) { return L + (v - xmin) / (xmax - xmin) * (W - L - R); };
    auto sy = [&](double v) { return H - B - (v - ymin) / (ymax - ymin) * (H - T - B); };
    
    //creating file
    ofstream o(file);
    o << fixed << setprecision(2);
    o << "<svg xmlns='http://www.w3.org/2000/svg' width='" << W << "' height='" << H
      << "' viewBox='0 0 " << W << " " << H << "'>\n";
    o << "<rect width='100%' height='100%' fill='white'/>\n";
    // grid + tick labels
    for (int i = 0; i <= 5; ++i) {
        double gx = xmin + (xmax - xmin) * i / 5.0, gy = ymin + (ymax - ymin) * i / 5.0;
        o << "<line x1='" << sx(gx) << "' y1='" << T << "' x2='" << sx(gx) << "' y2='" << H - B
          << "' stroke='#e5e5e5'/>\n";
        o << "<line x1='" << L << "' y1='" << sy(gy) << "' x2='" << W - R << "' y2='" << sy(gy)
          << "' stroke='#e5e5e5'/>\n";
        o << "<text x='" << sx(gx) << "' y='" << H - B + 20
          << "' font-size='12' text-anchor='middle' font-family='Arial'>" << setprecision(1) << gx << setprecision(2) << "</text>\n";
        o << "<text x='" << L - 8 << "' y='" << sy(gy) + 4
          << "' font-size='12' text-anchor='end' font-family='Arial'>" << setprecision(1) << gy << setprecision(2) << "</text>\n";
    }
    o << "<rect x='" << L << "' y='" << T << "' width='" << W - L - R << "' height='" << H - T - B
      << "' fill='none' stroke='#444'/>\n";
    // fitted parabola (smooth blue polyline, 300 samples)
    o << "<polyline fill='none' stroke='blue' stroke-width='3' points='";
    for (int i = 0; i <= 300; ++i) {
        double t = xmin + (xmax - xmin) * i / 300.0;
        o << sx(t) << "," << sy(f(t)) << " ";
    }
    o << "'/>\n";
    // data points (red dots)
    for (size_t i = 0; i < x.size(); ++i)
        o << "<circle cx='" << sx(x[i]) << "' cy='" << sy(y[i]) << "' r='6' fill='red' stroke='darkred'/>\n";
    // title + equation + axes labels
    o << "<text x='" << W / 2 << "' y='28' font-size='18' font-weight='bold' text-anchor='middle' font-family='Arial'>"
      << "Least-Squares Parabola Fit (Normal Equations)</text>\n";
    o << setprecision(3);
    o << "<text x='" << W / 2 << "' y='" << H - 12 << "' font-size='14' text-anchor='middle' font-family='Arial'>"
      << "y = " << c[0] << (c[1] < 0 ? " - " : " + ") << fabs(c[1]) << "x"
      << (c[2] < 0 ? " - " : " + ") << fabs(c[2]) << "x^2   (x axis: x, y axis: y)</text>\n";
    o << "</svg>\n";
}

int main() {
    int n;
    cout << "Enter number of points (at least 3): ";
    if (!(cin >> n) || n < 3) { cerr << "Need at least 3 points.\n"; return 1; }
    vector<double> x(n), y(n);
    cout << "Enter " << n << " points, one per line, as: x y\n";
    for (int i = 0; i < n; ++i) {
        cout << "Point " << i + 1 << ": ";
        if (!(cin >> x[i] >> y[i])) { cerr << "Invalid input.\n"; return 1; }
    }
    vector<double> xs = x;                 // need at least 3 distinct x values
    sort(xs.begin(), xs.end());
    int distinctCount = unique(xs.begin(), xs.end()) - xs.begin();
    if (distinctCount < 3) { cerr << "Need at least 3 distinct x values.\n"; return 1; }

    // 1) Vandermonde matrix A (n x 3): columns 1, x, x^2
    Mat A(n, vector<double>(3));
    for (int i = 0; i < n; ++i) { A[i][0] = 1; A[i][1] = x[i]; A[i][2] = x[i] * x[i]; }

    // 2) A^T A (3x3 symmetric)  and  A^T y (3x1)
    Mat AtA(3, vector<double>(3, 0.0));
    vector<double> Aty(3, 0.0);
    for (int r = 0; r < 3; ++r) {
        for (int c = 0; c < 3; ++c)
            for (int k = 0; k < n; ++k) AtA[r][c] += A[k][r] * A[k][c];
        for (int k = 0; k < n; ++k) Aty[r] += A[k][r] * y[k];
    }

    cout << "\n";
    printMat("Vandermonde A (n x 3)", A);
    printMat("\nA^T A (3 x 3)", AtA);
    cout << "\nA^T y = [" << fixed << setprecision(4) << Aty[0] << ", " << Aty[1] << ", " << Aty[2] << "]\n";

    // 3) Solve (A^T A) c = A^T y
    vector<double> c;
    if (!solve3x3(AtA, Aty, c)) {
        cerr << "A^T A is singular: need at least 3 distinct x values.\n";
        return 1;
    }
    cout << "\nBest-fit parabola:\n  y = " << setprecision(5) << c[0]
         << (c[1] < 0 ? " - " : " + ") << fabs(c[1]) << " x"
         << (c[2] < 0 ? " - " : " + ") << fabs(c[2]) << " x^2\n";

    // Quality of fit: residual sum of squares and R^2
    double mean = 0; for (double v : y) mean += v; mean /= n;
    double sse = 0, sst = 0;
    cout << "\n   x        y      fitted   residual\n";
    for (int i = 0; i < n; ++i) {
        double yh = c[0] + c[1] * x[i] + c[2] * x[i] * x[i];
        sse += (y[i] - yh) * (y[i] - yh); sst += (y[i] - mean) * (y[i] - mean);
        cout << setw(7) << setprecision(3) << x[i] << setw(9) << y[i] << setw(10) << yh
             << setw(10) << y[i] - yh << "\n";
    }
    cout << "\nSum of squared errors = " << setprecision(5) << sse
         << "\nR^2 = " << (sst > 0 ? 1 - sse / sst : 1.0) << "\n";

    writeSVG("fit.svg", x, y, c);
    cout << "\nWrote fit.svg (red = data, blue = fitted parabola)\n";
    return 0;
}